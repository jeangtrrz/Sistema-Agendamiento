<?php
/**
 * Configuración de la aplicación
 * Internet Cordillera - Sistema de Agendamiento
 */

// Configuración de base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'internet_agenda_user'); // Cambiar según tu configuración en cPanel
define('DB_PASS', 'EZ=$OqH3m21~'); // Cambiar según tu configuración en cPanel
define('DB_NAME', 'internet_agenda');

// Configuración de la aplicación
define('APP_NAME', 'Internet Cordillera - Sistema de Agendamiento');
define('APP_URL', 'https://internetpenalolen.cl/sistema_agendamiento'); // Cambiar a tu URL de producción
define('APP_TIMEZONE', 'America/Santiago');

// Configuración de sesión
define('SESSION_TIMEOUT', 3600); // 1 hora
define('SESSION_NAME', 'AGENDA_SESSION');

// Configuración de horarios
define('HORA_INICIO', '09:00');
define('HORA_FIN', '18:00');
define('DURACION_CITA_MINUTOS', 60); // 1 hora por defecto

// Tipos de citas
define('TIPOS_CITA', [
    'instalacion' => 'Instalación de Servicio',
    'retiro' => 'Retiro de Equipamiento',
    'soporte' => 'Visita de Soporte'
]);

// Tipos de eventos
define('TIPOS_EVENTO', [
    'reunion' => 'Reunión',
    'compromiso' => 'Compromiso',
    'evento' => 'Evento'
]);

// Perfiles de usuario
define('PERFILES', [
    'tecnico' => 'Técnico',
    'administrador' => 'Administrador'
]);

// Colores para tipos de cita
define('COLORES_CITA', [
    'instalacion' => '#4CAF50',
    'retiro' => '#FF9800',
    'soporte' => '#2196F3'
]);

// Días de operación (0 = Domingo, 6 = Sábado)
define('DIAS_OPERACION', [1, 2, 3, 4, 5, 6]); // Lunes a Sábado

// Manejo de errores
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0777, true);
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $logDir . '/error.log');

// Zona horaria
date_default_timezone_set(APP_TIMEZONE);

// Conexión a base de datos (función reutilizable)
function getDBConnection(): mysqli {
    try {
        if (!extension_loaded('mysqli')) {
            throw new Exception('La extensión mysqli no está habilitada en PHP.');
        }

        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            throw new Exception('Error de conexión: ' . $conn->connect_error);
        }
        
        // Configurar charset a UTF-8MB4
        $conn->set_charset("utf8mb4");
        
        // Ejecutar comando SQL para asegurar charset en la conexión
        $conn->query("SET NAMES utf8mb4");
        $conn->query("SET CHARACTER SET utf8mb4");
        
        return $conn;
    } catch (Exception $e) {
        die('Error de base de datos: ' . $e->getMessage());
    }
}

// Función para cerrar sesión
function closeDBConnection(?mysqli $conn = null): void {
    if ($conn instanceof mysqli) {
        $conn->close();
    }
}
?>

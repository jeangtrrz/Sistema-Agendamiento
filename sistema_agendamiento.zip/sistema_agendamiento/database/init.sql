-- =====================================================
-- BASE DE DATOS: Internet Cordillera - Agenda
-- VERSIÓN: 1.0
-- CREATED: 2026-05-22
-- =====================================================

-- Crear base de datos si no existe
CREATE DATABASE IF NOT EXISTS `internet_agenda` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `internet_agenda`;

-- =====================================================
-- TABLA: usuarios
-- =====================================================
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `perfil` ENUM('tecnico', 'administrador') NOT NULL DEFAULT 'tecnico',
  `estado` ENUM('activo', 'inactivo') NOT NULL DEFAULT 'activo',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_email` (`email`),
  INDEX `idx_perfil` (`perfil`),
  INDEX `idx_estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLA: citas
-- =====================================================
CREATE TABLE IF NOT EXISTS `citas` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `cliente_nombre` VARCHAR(100) NOT NULL,
  `cliente_telefono` VARCHAR(20) NOT NULL,
  `cliente_email` VARCHAR(100),
  `cliente_direccion` VARCHAR(255),
  `tipo_cita` ENUM('instalacion', 'retiro', 'soporte') NOT NULL,
  `fecha_cita` DATE NOT NULL,
  `hora_inicio` TIME NOT NULL,
  `hora_fin` TIME NOT NULL,
  `tecnico_id` INT(11) NOT NULL,
  `descripcion` TEXT,
  `estado` ENUM('pendiente', 'completada', 'cancelada') NOT NULL DEFAULT 'pendiente',
  `observaciones` TEXT,
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`tecnico_id`) REFERENCES `usuarios` (`id`),
  FOREIGN KEY (`created_by`) REFERENCES `usuarios` (`id`),
  INDEX `idx_fecha` (`fecha_cita`),
  INDEX `idx_tecnico` (`tecnico_id`),
  INDEX `idx_estado` (`estado`),
  INDEX `idx_tipo` (`tipo_cita`),
  CONSTRAINT `unique_cita_horario` UNIQUE KEY (`fecha_cita`, `hora_inicio`, `tecnico_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLA: eventos
-- =====================================================
CREATE TABLE IF NOT EXISTS `eventos` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `titulo` VARCHAR(150) NOT NULL,
  `tipo_evento` ENUM('reunion', 'compromiso', 'evento') NOT NULL,
  `fecha_evento` DATE NOT NULL,
  `hora_inicio` TIME NOT NULL,
  `hora_fin` TIME,
  `responsable_id` INT(11) NOT NULL,
  `lugar` VARCHAR(255),
  `descripcion` TEXT,
  `estado` ENUM('programado', 'completado', 'cancelado') NOT NULL DEFAULT 'programado',
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`responsable_id`) REFERENCES `usuarios` (`id`),
  FOREIGN KEY (`created_by`) REFERENCES `usuarios` (`id`),
  INDEX `idx_fecha_evento` (`fecha_evento`),
  INDEX `idx_responsable` (`responsable_id`),
  INDEX `idx_estado_evento` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLA: historial_citas
-- =====================================================
CREATE TABLE IF NOT EXISTS `historial_citas` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `cita_id` INT(11) NOT NULL,
  `accion` VARCHAR(100) NOT NULL,
  `descripcion` TEXT,
  `usuario_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`cita_id`) REFERENCES `citas` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  INDEX `idx_cita` (`cita_id`),
  INDEX `idx_fecha` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLA: reportes
-- =====================================================
CREATE TABLE IF NOT EXISTS `reportes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `titulo` VARCHAR(150) NOT NULL,
  `tipo` ENUM('completadas', 'pendientes', 'canceladas', 'por_tipo', 'por_tecnico') NOT NULL,
  `fecha_inicio` DATE NOT NULL,
  `fecha_fin` DATE NOT NULL,
  `datos_json` LONGTEXT,
  `generado_por` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`generado_por`) REFERENCES `usuarios` (`id`),
  INDEX `idx_tipo` (`tipo`),
  INDEX `idx_fecha` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- INSERTS: Usuarios iniciales
-- =====================================================

-- Usuario técnico: Freddy Morales (contraseña: 123456)
INSERT INTO `usuarios` (`nombre`, `email`, `password`, `perfil`, `estado`) VALUES
('Freddy Morales', 'freddy@internetcordillera.cl', '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36P4/KFm', 'tecnico', 'activo');

-- Usuario administrador: Jean Gutiérrez (contraseña: 123456)
INSERT INTO `usuarios` (`nombre`, `email`, `password`, `perfil`, `estado`) VALUES
('Jean Gutiérrez', 'jean@internetcordillera.cl', '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36P4/KFm', 'administrador', 'activo');

-- =====================================================
-- VISTAS: Estadísticas en tiempo real
-- =====================================================

-- Vista para citas completadas
CREATE OR REPLACE VIEW `vw_citas_completadas` AS
SELECT 
  COUNT(*) as total,
  tipo_cita,
  DATE(created_at) as fecha
FROM citas
WHERE estado = 'completada'
GROUP BY tipo_cita, DATE(created_at);

-- Vista para citas pendientes
CREATE OR REPLACE VIEW `vw_citas_pendientes` AS
SELECT 
  COUNT(*) as total,
  tipo_cita,
  DATE(created_at) as fecha
FROM citas
WHERE estado = 'pendiente'
GROUP BY tipo_cita, DATE(created_at);

-- Vista para resumen diario
CREATE OR REPLACE VIEW `vw_resumen_diario` AS
SELECT 
  DATE(fecha_cita) as fecha,
  COUNT(*) as total_citas,
  SUM(CASE WHEN estado = 'completada' THEN 1 ELSE 0 END) as completadas,
  SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
  SUM(CASE WHEN estado = 'cancelada' THEN 1 ELSE 0 END) as canceladas
FROM citas
GROUP BY DATE(fecha_cita);

-- Vista para citas por técnico
CREATE OR REPLACE VIEW `vw_citas_por_tecnico` AS
SELECT 
  u.id,
  u.nombre,
  COUNT(c.id) as total_citas,
  SUM(CASE WHEN c.estado = 'completada' THEN 1 ELSE 0 END) as completadas,
  SUM(CASE WHEN c.estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes
FROM usuarios u
LEFT JOIN citas c ON u.id = c.tecnico_id
WHERE u.perfil = 'tecnico'
GROUP BY u.id, u.nombre;

-- =====================================================
-- ÍNDICES ADICIONALES para optimización
-- =====================================================
ALTER TABLE `citas` ADD INDEX `idx_cliente_email` (`cliente_email`);
ALTER TABLE `citas` ADD INDEX `idx_fecha_hora` (`fecha_cita`, `hora_inicio`);
ALTER TABLE `usuarios` ADD INDEX `idx_estado_perfil` (`estado`, `perfil`);

-- =====================================================
-- FIN DEL SCRIPT
-- =====================================================
